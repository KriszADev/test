import { IRegisterUser } from './IRegisterUser';

export interface ILoginUser extends IRegisterUser {

}
