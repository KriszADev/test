export interface ITokenResponse {
    token: string;
  }
  