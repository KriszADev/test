export interface IRegisterUser {
    emailAddress?: string;
    password?: string;
    firstName?: string;
    lastName?: string;

}