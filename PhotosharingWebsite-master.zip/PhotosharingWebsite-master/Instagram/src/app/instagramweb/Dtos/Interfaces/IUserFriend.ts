
export interface IUserFriend {
    friendId?: number;
    userId?: number;
        
}